frameworkShortcodeAtts={
	attributes:[
			{
				label:"Download Link Text",
				id:"text",
				help:"Enter the text for link."
			},
			{
				label:"Format of files",
				id:"format",
				help:"Enter the format of files."
			},
			{
				label:"Link of Download Link",
				id:"link",
				help:"Enter the link for download link. (e.g. http://demolink.org)"
			}
	],
	defaultContent:"",
	shortcode:"downloadlink"
};
